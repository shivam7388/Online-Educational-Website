<!DOCTYPE html>
<html>
  <head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

<link rel="stylesheet" type="text/css" href="about.css">
<link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
<title>Learning Hub</title>
</head>
<body>
 <?php require '..\nav.php' ?>
<div class="section">
 <div class="con">
  <div class="con-section">
  <div class="title">
   <h1>Abouts Us</h1>
</div>
<div class="contents">
<h3>Welcome to our online learning platform!</h3>
<p> We offer courses in some of the most in-demand programming languages today, including HTML, CSS, JavaScript, Python, and PHP. 
we've created a variety of resources to support your learning, including video lectures and projects.
</p>
<div class="buttom">
<a href="">Read More</a>
</div>
</div>
<div class="social">
<a href=""><i class="fab fa-facebook-f"></i></a>
<a href=""><i class="fab fa-twitter"></i></a>
<a href=""><i class="fab fa-instagram"></i></a>
</div>

</div>
<div class="image-section">
 <img src="profile-1.jpg">
</div>
</div>
</div>

</div>



</body>
</html><!DOCTYPE html>
<html>
  <head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

<link rel="stylesheet" type="text/css" href="about.css">
<link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
<title>Learning Hub</title>
</head>
<body>
 <?php require '..\nav.php' ?>
<div class="section">
 <div class="con">
  <div class="con-section">
  <div class="title">
   <h1>Abouts Us</h1>
</div>
<div class="contents">
<h3>Welcome to our online learning platform!</h3>
<p> We offer courses in some of the most in-demand programming languages today, including HTML, CSS, JavaScript, Python, and PHP. 
we've created a variety of resources to support your learning, including video lectures and projects.
</p>
<div class="buttom">
<a href="">Read More</a>
</div>
</div>
<div class="social">
<a href=""><i class="fab fa-facebook-f"></i></a>
<a href=""><i class="fab fa-twitter"></i></a>
<a href=""><i class="fab fa-instagram"></i></a>
</div>

</div>
<div class="image-section">
 <img src="profile-1.jpg">
</div>
</div>
</div>

</div>



</body>
</html><!DOCTYPE html>
<html>
  <head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

<link rel="stylesheet" type="text/css" href="about.css">
<link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
<title>Learning Hub</title>
</head>
<body>
 <?php require '..\nav.php' ?>
<div class="section">
 <div class="con">
  <div class="con-section">
  <div class="title">
   <h1>Abouts Us</h1>
</div>
<div class="contents">
<h3>Welcome to our online learning platform!</h3>
<p> We offer courses in some of the most in-demand programming languages today, including HTML, CSS, JavaScript, Python, and PHP. 
we've created a variety of resources to support your learning, including video lectures and projects.
</p>
<div class="buttom">
<a href="">Read More</a>
</div>
</div>
<div class="social">
<a href=""><i class="fab fa-facebook-f"></i></a>
<a href=""><i class="fab fa-twitter"></i></a>
<a href=""><i class="fab fa-instagram"></i></a>
</div>

</div>
<div class="image-section">
 <img src="profile-1.jpg">
</div>
</div>
</div>

</div>



</body>
</html>