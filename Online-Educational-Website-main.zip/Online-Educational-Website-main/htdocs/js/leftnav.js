console.log("hi");
function myFun(){
var x=document.getElementById("html");
var y=document.getElementById("css");
x.style.display="none";
 if(x.style.display=="none"){
x.style.display="block";
 console.log("block");
}
else{ 
x.style.display="block";
 console.log("bl");
}
}
function myFuns(){
var x=document.getElementById("css");
 if(x.style.display=="none"){
x.style.display="block";
}
else{ 
x.style.display="none";
}
}